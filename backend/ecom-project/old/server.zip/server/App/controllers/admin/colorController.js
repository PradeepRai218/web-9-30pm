const colorModal = require("../../modal/color");

let colorController = {

  colorCreate: async (req, res) => {

    const dataSave = req.body;

    // console.log(dataSave);

    await colorModal(dataSave).save()
    .then((result) => {
      res.send({
        _status: true,
        _message: "Color Added New",
        _data : result
      });
    })
    .catch((error) => {
        res.send({
          _status: false,
          _message: "Something went Wrong !",
          _error : error,
          _data : ""
        });
    })

    
  },


  colorView: async (req, res) => {

    var records = await colorModal.find();

    res.send({
      _status: true,
      _message: "Color View",
      _records : records
    });
  },

  colorDelete: (req, res) => {
    res.send({
      _status: true,
      _message: "Color Delete",
    });
  },


  colorUpdate: (req, res) => {
    res.send({
      _status: true,
      _message: "Color Delete",
    });
  },


};

module.exports={colorController}
// let colorCreate=(req,res)=>{

//      res.send({
//         _status:true,
//         _message:"Color Added New"
//     })
// }

// let colorView=(req,res)=>{
//      res.send({
//         _status:true,
//         _message:"Color View Controller"
//     })
// }

// let colorDelete=(req,res)=>{
//      res.send({
//         _status:true,
//         _message:"Color Delete"
//     })
// }

// let colorUpdate=(req,res)=>{
//      res.send({
//         _status:true,
//         _message:"Color Update"
//     })
// }

// module.exports={colorCreate,colorView,colorDelete,colorUpdate}
