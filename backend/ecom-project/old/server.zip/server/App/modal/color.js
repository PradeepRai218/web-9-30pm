const mongoose = require('mongoose');

const schema = new mongoose.Schema({
  name: {
    type : String,
    minLength : [3, 'Minimum 3 charater is required'],
    maxLength : [15, 'Maximum 15 charater is allowed'],
    required : [true, 'Name is required']
  },
  code:  {
    type : String,
    required : [true, 'Code is required']
  },
  quantity : {
    type : Number,
    required : [true, "Quantity is required"],
    min : [1, 'Minimum 1 value is required'],
    max : [5, 'Maximum 5 value is allowed'],
  }
});

const colorModal = mongoose.model('colors', schema);


module.exports = colorModal;